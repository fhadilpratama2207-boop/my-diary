import { initializeApp } from "https://www.gstatic.com/firebasejs/12.17.1/firebase-app.js";
import { getFirestore, doc, getDoc, setDoc, collection, addDoc, updateDoc, deleteDoc, onSnapshot, query, orderBy } from "https://www.gstatic.com/firebasejs/12.17.1/firebase-firestore.js";

const firebaseConfig = {
  apiKey: "AIzaSyCrqhf3hd1PdaA0hDqeGSvh1lECd9cP-3E",
  authDomain: "mydiary220710.firebaseapp.com",
  projectId: "mydiary220710",
  storageBucket: "mydiary220710.firebasestorage.app",
  messagingSenderId: "473215915221",
  appId: "1:473215915221:web:eee32596e8b66bacebbe5c"
};

const app = initializeApp(firebaseConfig);
const db = getFirestore(app);

const CORRECT_PIN = "01072026";
let currentPin = null;
let currentStoryId = null;
let currentPhotoBase64 = null;
let unsubscribe = null;

// Elements
const lockScreen = document.getElementById("lockScreen");
const setupScreen = document.getElementById("setupScreen");
const mainScreen = document.getElementById("mainScreen");
const storyModal = document.getElementById("storyModal");
const pinInput = document.getElementById("pinInput");
const pinError = document.getElementById("pinError");
const storiesList = document.getElementById("storiesList");
const lovedOneDisplay = document.getElementById("lovedOneDisplay");

// ========== LOCK ==========
document.getElementById("unlockBtn").addEventListener("click", async () => {
  const pin = pinInput.value.trim();
  if (pin !== CORRECT_PIN) {
    pinError.textContent = "PIN salah 💔";
    return;
  }
  pinError.textContent = "";
  currentPin = pin;

  const diaryRef = doc(db, "diaries", pin);
  const snap = await getDoc(diaryRef);

  if (!snap.exists()) {
    // Pertama kali
    lockScreen.classList.add("hidden");
    setupScreen.classList.remove("hidden");
  } else {
    const data = snap.data();
    if (data.lovedOne) {
      lovedOneDisplay.textContent = `Untuk: ${data.lovedOne} 💕`;
    }
    showMain();
  }
});

pinInput.addEventListener("keypress", (e) => {
  if (e.key === "Enter") document.getElementById("unlockBtn").click();
});

// ========== SETUP ==========
document.getElementById("saveSetupBtn").addEventListener("click", async () => {
  const lovedOne = document.getElementById("lovedOneInput").value.trim();
  await setDoc(doc(db, "diaries", currentPin), {
    lovedOne: lovedOne || null,
    createdAt: new Date().toISOString()
  });
  if (lovedOne) lovedOneDisplay.textContent = `Untuk: ${lovedOne} 💕`;
  setupScreen.classList.add("hidden");
  showMain();
});

document.getElementById("skipSetupBtn").addEventListener("click", async () => {
  await setDoc(doc(db, "diaries", currentPin), {
    lovedOne: null,
    createdAt: new Date().toISOString()
  });
  setupScreen.classList.add("hidden");
  showMain();
});

// ========== MAIN ==========
function showMain() {
  mainScreen.classList.remove("hidden");
  loadStories();
}

document.getElementById("logoutBtn").addEventListener("click", () => {
  if (unsubscribe) unsubscribe();
  currentPin = null;
  mainScreen.classList.add("hidden");
  lockScreen.classList.remove("hidden");
  pinInput.value = "";
});

// ========== LOAD STORIES ==========
function loadStories() {
  const q = query(collection(db, "diaries", currentPin, "stories"), orderBy("createdAt", "desc"));
  unsubscribe = onSnapshot(q, (snapshot) => {
    storiesList.innerHTML = "";
    if (snapshot.empty) {
      storiesList.innerHTML = `
        <div class="empty-state">
          <div class="big-heart">💙</div>
          <p>Belum ada cerita.<br>Yuk mulai menulis...</p>
        </div>`;
      return;
    }
    snapshot.forEach((docSnap) => {
      const s = docSnap.data();
      const card = document.createElement("div");
      card.className = "story-card";
      card.onclick = () => openStory(docSnap.id, s);
      card.innerHTML = `
        \( {s.photo ? `<img src=" \){s.photo}" class="story-photo-thumb" />` : ""}
        <h3>${s.title || "Tanpa Judul"}</h3>
        <p>${s.content || ""}</p>
        <div class="story-meta">
          <span>${formatDate(s.createdAt)}</span>
          <span>❤️</span>
        </div>
      `;
      storiesList.appendChild(card);
    });
  });
}

function formatDate(iso) {
  const d = new Date(iso);
  return d.toLocaleDateString("id-ID", { day: "numeric", month: "long", year: "numeric" });
}

// ========== ADD / EDIT ==========
document.getElementById("addStoryBtn").addEventListener("click", () => {
  currentStoryId = null;
  currentPhotoBase64 = null;
  document.getElementById("modalTitle").textContent = "Cerita Baru";
  document.getElementById("storyTitle").value = "";
  document.getElementById("storyContent").value = "";
  document.getElementById("photoPreview").classList.add("hidden");
  document.getElementById("deleteStoryBtn").classList.add("hidden");
  document.getElementById("photoBtnText").textContent = "📷 Tambah Foto";
  storyModal.classList.remove("hidden");
});

document.getElementById("closeModalBtn").addEventListener("click", () => {
  storyModal.classList.add("hidden");
});

function openStory(id, data) {
  currentStoryId = id;
  currentPhotoBase64 = data.photo || null;
  document.getElementById("modalTitle").textContent = "Edit Cerita";
  document.getElementById("storyTitle").value = data.title || "";
  document.getElementById("storyContent").value = data.content || "";
  document.getElementById("deleteStoryBtn").classList.remove("hidden");

  if (data.photo) {
    document.getElementById("previewImg").src = data.photo;
    document.getElementById("photoPreview").classList.remove("hidden");
    document.getElementById("photoBtnText").textContent = "📷 Ganti Foto";
  } else {
    document.getElementById("photoPreview").classList.add("hidden");
    document.getElementById("photoBtnText").textContent = "📷 Tambah Foto";
  }
  storyModal.classList.remove("hidden");
}

// Photo handling + compress
document.getElementById("photoInput").addEventListener("change", async (e) => {
  const file = e.target.files[0];
  if (!file) return;

  const compressed = await compressImage(file, 600, 0.6); // max width 600px, quality 60%
  currentPhotoBase64 = compressed;
  document.getElementById("previewImg").src = compressed;
  document.getElementById("photoPreview").classList.remove("hidden");
  document.getElementById("photoBtnText").textContent = "📷 Ganti Foto";
});

document.getElementById("removePhotoBtn").addEventListener("click", () => {
  currentPhotoBase64 = null;
  document.getElementById("photoPreview").classList.add("hidden");
  document.getElementById("photoInput").value = "";
  document.getElementById("photoBtnText").textContent = "📷 Tambah Foto";
});

function compressImage(file, maxWidth, quality) {
  return new Promise((resolve) => {
    const reader = new FileReader();
    reader.onload = (e) => {
      const img = new Image();
      img.onload = () => {
        const canvas = document.createElement("canvas");
        let width = img.width;
        let height = img.height;
        if (width > maxWidth) {
          height = (height * maxWidth) / width;
          width = maxWidth;
        }
        canvas.width = width;
        canvas.height = height;
        const ctx = canvas.getContext("2d");
        ctx.drawImage(img, 0, 0, width, height);
        resolve(canvas.toDataURL("image/jpeg", quality));
      };
      img.src = e.target.result;
    };
    reader.readAsDataURL(file);
  });
}

// Save
document.getElementById("saveStoryBtn").addEventListener("click", async () => {
  const title = document.getElementById("storyTitle").value.trim();
  const content = document.getElementById("storyContent").value.trim();
  if (!title && !content) {
    alert("Isi minimal judul atau cerita ya 💙");
    return;
  }

  const data = {
    title,
    content,
    photo: currentPhotoBase64,
    updatedAt: new Date().toISOString()
  };

  if (currentStoryId) {
    await updateDoc(doc(db, "diaries", currentPin, "stories", currentStoryId), data);
  } else {
    data.createdAt = new Date().toISOString();
    await addDoc(collection(db, "diaries", currentPin, "stories"), data);
  }
  storyModal.classList.add("hidden");
});

// Delete
document.getElementById("deleteStoryBtn").addEventListener("click", async () => {
  if (!confirm("Yakin mau hapus cerita ini?")) return;
  await deleteDoc(doc(db, "diaries", currentPin, "stories", currentStoryId));
  storyModal.classList.add("hidden");
});